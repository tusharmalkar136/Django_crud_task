# Task Manager

This is a simple Django application with RESTful APIs for managing tasks.

## Setup

1. Install dependencies:
   ```bash
   pip install -r requirements.txt


2. Apply migrations:
   ```bash
   python manage.py make migrations
   python manage.py migrate


3. Run the development server:
  ```bash
      python manage.py runserver.


[//]: # ()

Open your browser and go to http://localhost:8000.

[//]: # (APIs)

List/Create Tasks: http://localhost:8000/api/tasks/
Retrieve/Update/Delete Task: http://localhost:8000/api/tasks/{task_id}/