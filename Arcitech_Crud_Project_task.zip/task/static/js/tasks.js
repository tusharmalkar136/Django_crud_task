
// Implement JavaScript functions for CRUD operations
// Use Fetch API or any library like Axios for making API requests

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Manager</title>
</head>
<body>
    <h1>Task Manager</h1>

    <!-- Form to create a new task -->
    <form id="task-form">
        <label for="title">Title:</label>
        <input type="text" id="title" required>
        <label for="description">Description:</label>
        <textarea id="description" required></textarea>
        <label for="status">Status:</label>
        <select id="status" required>
            <option value="Pending">Pending</option>
            <option value="Completed">Completed</option>
        </select>
        <button type="button" onclick="createTask()">Add Task</button>
    </form>

    <!-- List to display all tasks -->
    <ul id="task-list"></ul>

    <script>
        // Function to create a new task
        function createTask() {
            const title = document.getElementById('title').value;
            const description = document.getElementById('description').value;
            const status = document.getElementById('status').value;

            // Make a POST request to create a new task
            fetch('http://localhost:8000/api/tasks/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    title: title,
                    description: description,
                    status: status,
                }),
            })
            .then(response => response.json())
            .then(data => {
                // Add the new task to the list
                const taskList = document.getElementById('task-list');
                const listItem = document.createElement('li');
                listItem.textContent = `${data.title} - ${data.status}`;
                taskList.appendChild(listItem);

                // Clear the form fields
                document.getElementById('title').value = '';
                document.getElementById('description').value = '';
                document.getElementById('status').value = 'Pending';
            })
            .catch(error => console.error('Error:', error));
        }

        // Function to fetch and display all tasks
        function fetchTasks() {
            // Make a GET request to fetch all tasks
            fetch('http://localhost:8000/api/tasks/')
            .then(response => response.json())
            .then(data => {
                // Display tasks in the list
                const taskList = document.getElementById('task-list');
                taskList.innerHTML = '';
                data.forEach(task => {
                    const listItem = document.createElement('li');
                    listItem.textContent = `${task.title} - ${task.status}`;

                    // Add buttons for updating and deleting tasks
                    const updateButton = document.createElement('button');
                    updateButton.textContent = 'Update';
                    updateButton.onclick = function() {
                        updateTask(task.id, task.title, task.description, task.status);
                    };

                    const deleteButton = document.createElement('button');
                    deleteButton.textContent = 'Delete';
                    deleteButton.onclick = function() {
                        deleteTask(task.id);
                    };

                    listItem.appendChild(updateButton);
                    listItem.appendChild(deleteButton);

                    taskList.appendChild(listItem);
                });
            })
            .catch(error => console.error('Error:', error));
        }

        // Function to update a task
        function updateTask(id, title, description, status) {
            // Implement updating task logic here
            console.log(`Update task with ID ${id}`);
        }

        // Function to delete a task
        function deleteTask(id) {
            // Implement deleting task logic here
            console.log(`Delete task with ID ${id}`);
        }

        // Fetch and display tasks on page load
        fetchTasks();
    </script>
</body>
</html>
