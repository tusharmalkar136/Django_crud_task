# i have created this file
# from django.http import HttpResponse
# from django.shortcuts import render


# def index(request):
#     param = {'name':'Tushar','place':'Google'}
#     return render(request,'index.html',param)



# def index(request):
#     return HttpResponse('''<h1>Hello Tushar Welcome to Django<h1/> <a
#     href="https://www.youtube.com/watch?v=EPLz5pKl_jU&list=PLI4OVrCFuY56E57FdYzFNSWcEDS-ZKK26">
#     TusharWithYoutube</a>''')


# def about(request):
#     return HttpResponse('''<h2>Hello About<h2/> <a
#                         href="https://dummyjson.com/">
#                         MyAbout<a/>''')






